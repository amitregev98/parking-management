package server;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;

import gui.ServerMessageFrameController;
import javafx.application.Platform;
import ocsf.server.AbstractServer;
import ocsf.server.ConnectionToClient;

public class EchoServer extends AbstractServer {

    public static final int DEFAULT_PORT = 5555;
    private mysqlConnection db;
    public static ServerMessageFrameController messageController;
    private ArrayList<String> DisconnectedIPs = new ArrayList<>();
    private int numOfClients = 0;

    // Constructor - initializes server with given port and database connection
    public EchoServer(int port) {
        super(port);
        db = new mysqlConnection();
    }

    // Called when a client connects to the server
    @Override
    protected void clientConnected(ConnectionToClient client) {
        String ip = client.getInetAddress().getHostAddress();
        DisconnectedIPs.add(ip);
        numOfClients++;
        Platform.runLater(() -> {
            messageController.appendMessage("Client connected: " + ip);
            messageController.appendMessage("Connected clients: " + getNumberOfClients());
            printConnectedIPs();
        });
    }

    // Called when a client disconnects unexpectedly
    @Override
    protected synchronized void clientException(ConnectionToClient client, Throwable exception) {
        System.out.println("Client exception: " + exception.getMessage());

        ArrayList<String> Copy = new ArrayList<>(DisconnectedIPs);
        String Exist = getConnectedIPs();
        String[] existingIPs = Exist.split(" ");

        for (int i = 0; i < existingIPs.length; i++) {
            System.out.print(existingIPs[i]);
            if (Copy.contains(existingIPs[i])) {
                Copy.remove(existingIPs[i]);
            }
        }

        messageController.appendMessage("Disconnected IP:" + Copy.toString());
        DisconnectedIPs.remove(Copy.get(0).toString());

        Platform.runLater(() -> {
            messageController.appendMessage("Connected clients: " + getNumberOfClients());
            printConnectedIPs();
        });
    }

    // Called when a client disconnects normally
    @Override
    protected synchronized void clientDisconnected(ConnectionToClient client) {
        Platform.runLater(() -> {
            messageController.appendMessage("Client disconnected: ");
            messageController.appendMessage("Connected clients: " + getNumberOfClients());
            printConnectedIPs();
        });
    }

    // Called when the server starts
    @Override
    protected void serverStarted() {
        Platform.runLater(() -> {
            messageController.appendMessage("Server is now listening on port " + getPort());
            messageController.appendMessage("Connected clients: " + getNumberOfClients());
            printConnectedIPs();
        });
    }

    // Called when the server stops
    @Override
    protected void serverStopped() {
        Platform.runLater(() -> {
            messageController.appendMessage("Server has stopped listening for connections.");
        });
    }

    // Prints all connected client IPs to the GUI
    private void printConnectedIPs() {
        StringBuilder sb = new StringBuilder("Connected IPs:\n");
        for (Thread t : getClientConnections()) {
            if (t instanceof ConnectionToClient client) {
                sb.append(client.getInetAddress().getHostAddress()).append("\n");
            }
        }
        messageController.appendMessage(sb.toString());
    }

    // Returns a string of all connected client IPs
    private String getConnectedIPs() {
        StringBuilder sb = new StringBuilder("");
        for (Thread t : getClientConnections()) {
            if (t instanceof ConnectionToClient client && client.getInetAddress() != null && client.getInetAddress().getHostAddress() != null) {
                sb.append(client.getInetAddress().getHostAddress()).append(" ");
            }
        }
        return sb.toString();
    }

    // Handles messages received from clients
    @Override
    public void handleMessageFromClient(Object msg, ConnectionToClient client) {
        String clientIP = client.getInetAddress().getHostAddress();
        messageController.appendMessage("Client IP: " + clientIP);
        messageController.appendMessage("Message received: " + msg + " from " + client);

        if (!(msg instanceof String)) {
            sendToClientSafely(client, "Invalid message format");
            return;
        }

        String rawMessage = ((String) msg).trim();
        String[] parts = rawMessage.split("\\s+");

        ArrayList<String> messageList = new ArrayList<>();
        for (String part : parts) messageList.add(part);

        if (messageList.size() == 1) {
            String orderNumberStr = messageList.get(0);
            try {
                int orderNumber = Integer.parseInt(orderNumberStr);
                if (db.orderExists(orderNumber)) {
                    String details = db.printOrderById(orderNumber);
                    sendToClientSafely(client, details);
                } else {
                    sendToClientLabelUpdate(client, "Order not found.");
                }
            } catch (NumberFormatException e) {
                sendToClientLabelUpdate(client, "Invalid order number format.");
            }
            return;
        }

        if (messageList.size() == 7 && parseData(messageList, client)) {
            try {
                int parkingSpace = Integer.parseInt(messageList.get(1));
                int orderNumber = Integer.parseInt(messageList.get(2));
                Date orderDate = Date.valueOf(messageList.get(3));
                messageController.appendMessage("parking space" + parkingSpace);
                messageController.appendMessage("orderNumber" + orderNumber);
                messageController.appendMessage("orderDate" + orderDate.toString());
                if (db.isDateValid(orderNumber, orderDate) == false) {
                    sendToClientLabelUpdate(client, "date should be within 24 hours to 7 days!");
                    return;
                } else if (db.checkParkingSpaceIfExists(parkingSpace) == true) {
                    if (db.isDateTakenForParkingSpace(parkingSpace, orderDate) == true) {
                        sendToClientLabelUpdate(client, "parking space already taken\nchange parking space or date");
                        return;
                    }
                    db.updateParkingSpace(orderNumber, parkingSpace);
                    db.updateOrderDate(orderNumber, orderDate);
                    sendToClientLabelUpdate(client, "Server: Data received and saved to database.");
                } else {
                    sendToClientLabelUpdate(client, "Parking Space doesn't exist.");
                }
            } catch (Exception e) {
                sendToClientLabelUpdate(client, "Error processing data.");
            }
        } else {
            sendToClientLabelUpdate(client, "Server: Invalid input format. \nExpected exactly 6 values separated by spaces.");
        }
    }

    // Validates the structure and format of incoming message data
    private boolean parseData(ArrayList<String> msg, ConnectionToClient client) {
        if (msg == null || msg.size() != 7) {
            sendToClientLabelUpdate(client, "Error: you left empty field!");
            return false;
        }
        try {
            Integer.parseInt(msg.get(1));
            Date.valueOf(msg.get(3));
        } catch (Exception e) {
            sendToClientLabelUpdate(client, "Error: Invalid data format.\n int for parking place, date for parking date (yyyy-mm-dd).");
            return false;
        }
        return true;
    }

    // Sends a message back to a client safely
    private void sendToClientSafely(ConnectionToClient client, String message) {
        try {
            client.sendToClient(message);
        } catch (IOException e) {
            messageController.appendMessage("Failed to send message to client: " + e.getMessage());
        }
    }

    // Entry point to run the server
    public static void main(String[] args) {
        int port = DEFAULT_PORT;
        if (args.length > 0) {
            try {
                port = Integer.parseInt(args[0]);
            } catch (NumberFormatException ignored) {}
        }

        EchoServer server = new EchoServer(port);
        try {
            server.listen();
        } catch (Exception ex) {
            messageController.appendMessage("ERROR - Could not listen for clients!");
        }
    }

    // Sends a formatted error message to client
    private void sendToClientLabelUpdate(ConnectionToClient client, String message) {
        try {
            client.sendToClient("ORDER_ERROR: " + message);
        } catch (IOException e) {
            messageController.appendMessage("Failed to send error message to client: " + e.getMessage());
        }
    }
} // End of EchoServer
