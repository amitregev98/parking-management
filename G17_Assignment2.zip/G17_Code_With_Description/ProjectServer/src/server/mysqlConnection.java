package server;

import java.sql.*;
import java.util.Scanner;

import gui.ServerMessageFrameController;
import gui.ServerPortFrameController;

public class mysqlConnection {
	
	private Connection conn;

	// Constructor: establishes a connection to the database
	public mysqlConnection() {
		connectToDB();
	}

	// Connects to the MySQL database
	private void connectToDB() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
		} catch (Exception ex) {
			System.out.println("Driver definition failed");
			return;
		}

		try {
			conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/parking?useSSL=false&serverTimezone=Asia/Jerusalem",
				"root", "Aa123456"
			);
			if (EchoServer.messageController != null) {
				EchoServer.messageController.appendMessage("SQL connection succeeded.");
			}
		} catch (SQLException ex) {
			EchoServer.messageController.appendMessage("SQLException: " + ex.getMessage());
			EchoServer.messageController.appendMessage("SQLState: " + ex.getSQLState());
			EchoServer.messageController.appendMessage("VendorError: " + ex.getErrorCode());
		}
	}

	// Returns a valid database connection, reconnects if necessary
	public Connection getConnection() {
		try {
			if (conn == null || conn.isClosed()) {
				EchoServer.messageController.appendMessage("Connection is null or closed. Reconnecting...");
				connectToDB();
			}
		} catch (SQLException e) {
			EchoServer.messageController.appendMessage("Error while checking connection state:");
			e.printStackTrace();
			return null;
		}
		return conn;
	}

	// Checks if an order exists in the database by order number
	public boolean orderExists(int orderNumber) {
		String query = "SELECT 1 FROM orders WHERE order_number = ?";
		try (PreparedStatement stmt = conn.prepareStatement(query)) {
			stmt.setInt(1, orderNumber);
			ResultSet rs = stmt.executeQuery();

			if (rs.next()) {
				EchoServer.messageController.appendMessage("Found");
				return true;
			}
		} catch (SQLException e) {
			EchoServer.messageController.appendMessage("Error checking order existence: " + e.getMessage());
			return false;
		}
		return false;
	}

	// Retrieves and formats order information by order number
	public String printOrderById(int orderNumber) {
		String query = "SELECT * FROM orders WHERE order_number = ?";
		String message = "";

		try (PreparedStatement stmt = conn.prepareStatement(query)) {
			stmt.setInt(1, orderNumber);
			ResultSet rs = stmt.executeQuery();

			if (rs.next()) {
				message += 
					 rs.getInt("parking_space") + " " +
					 rs.getInt("order_number") + " " +
					 rs.getDate("order_date") + " " + 
					 rs.getInt("confirmation_code") + " " +
					 rs.getInt("subscriber_id") + " " +
					 rs.getDate("date_of_placing_an_order") + " ";
				return message;
			} else {
				return "No order found with number: " + orderNumber;
			}

		} catch (SQLException e) {
			return "Error: " + e.getMessage();
		}
	}

	// Checks if a parking space already exists in the orders
	public boolean checkParkingSpaceIfExists(int parkingSpaceToCheck) {
		String query = "SELECT 1 FROM orders WHERE parking_space = ? LIMIT 1";

		try (PreparedStatement stmt = conn.prepareStatement(query)) {
			stmt.setInt(1, parkingSpaceToCheck);
			ResultSet rs = stmt.executeQuery();

			return rs.next();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}

	// Checks if a given date is already taken for a specific parking space
	public boolean isDateTakenForParkingSpace(int parkingSpace, Date date) throws Exception {
		String query = "SELECT 1 FROM orders WHERE parking_space = ? AND order_date = ? LIMIT 1";

		try (PreparedStatement stmt = conn.prepareStatement(query)) {
			stmt.setInt(1, parkingSpace);
			stmt.setDate(2, date);
			ResultSet rs = stmt.executeQuery();
			return rs.next();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception("Error checking date for parking space: " + e.getMessage());
		}
	}

	// Validates if the requested date is within 1 to 7 days after the order placing date
	public boolean isDateValid(int orderNumber, Date requestedDate) throws Exception {
		String query = "SELECT date_of_placing_an_order FROM orders WHERE order_number = ?";

		try (PreparedStatement stmt = conn.prepareStatement(query)) {
			stmt.setInt(1, orderNumber);
			ResultSet rs = stmt.executeQuery();

			if (rs.next()) {
				Date placingDate = rs.getDate("date_of_placing_an_order");

				long placingTime = placingDate.getTime();
				long minAllowed = placingTime + 1L * 24 * 60 * 60 * 1000L;
				long maxAllowed = placingTime + 7L * 24 * 60 * 60 * 1000L;

				long requestedTime = requestedDate.getTime();

				return (requestedTime >= minAllowed && requestedTime <= maxAllowed);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception("Error checking date validity: " + e.getMessage());
		}

		return false;
	}

	// Updates the parking space number for a specific order
	public void updateParkingSpace(int orderNumber, int newSpace) throws Exception {
		String query = "UPDATE orders SET parking_space = ? WHERE order_number = ?";
		try (PreparedStatement stmt = conn.prepareStatement(query)) {
			if (checkParkingSpaceIfExists(newSpace)) {
				stmt.setInt(1, newSpace);
				stmt.setInt(2, orderNumber);
			} else {
				EchoServer.messageController.appendMessage("Parking space is not Exists.");
			}
			int rows = stmt.executeUpdate();
			if (rows > 0) {
				EchoServer.messageController.appendMessage("Parking space updated successfully.");
			} else {
				EchoServer.messageController.appendMessage("Failed to update parking space.");
				return;
			}
		} catch (SQLException e) {
			EchoServer.messageController.appendMessage("Error updating parking space: " + e.getMessage());
			return;
		}
	}

	// Updates the order date for a given order
	public void updateOrderDate(int orderNumber, Date newDate) {
		String query = "UPDATE orders SET order_date = ? WHERE order_number = ?";
		try (PreparedStatement stmt = conn.prepareStatement(query)) {
			stmt.setDate(1, newDate);
			stmt.setInt(2, orderNumber);
			int rows = stmt.executeUpdate();
			if (rows > 0) {
				EchoServer.messageController.appendMessage("Order date updated successfully.");
			} else {
				EchoServer.messageController.appendMessage("Failed to update order date.");
			}
		} catch (SQLException e) {
			EchoServer.messageController.appendMessage("Error updating order date: " + e.getMessage());
		}
	}
}
